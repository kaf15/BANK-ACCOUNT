# BankAccount
Kata Societe Generale

This is the kata of the bank account of societe generale
